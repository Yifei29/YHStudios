# System Info of YOS 0.2.0.0 Alpha

### Version: 0.2.0.0
### Type: Alpha
### Official: Yes
### Release Name: nil
### DataBase Keys: 3 (1.2 KB Storage)

# Updates (0.2.0)
1. Added Diagnostics App
2. Added Space to Password prompt
3. Updated DataBase-Data-Saving-Method
4. Added Loading Prompt to YDocs
5. Updated Loading Prompt
6. Updated System Info

# Creators:

### Yifei29: Main Developer
A 9-Year-Old Lua and Python developer.
### Chambers30101: Backup Developer
A 10-Year-Old Roblox Builder and Devloper
### FireAddict: Admin


24
