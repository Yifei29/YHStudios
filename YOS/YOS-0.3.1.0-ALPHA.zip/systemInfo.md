# System Info of YOS 0.3.1.0 Alpha

### Version: 0.3.1.0
### Type: Alpha
### Official: Yes
### Release Name: nil
### DataBase Keys: 3 (10.2 KB Storage)

# Updates (0.3.1.0)
1. Calculator now in Beta
2. YDocs now in Full Release (Updates Coming)
3. Added Clock
4. Diagnostics now in Beta
5. Bug Fixes
6. Fixed Calculator opening while using YDocs
7. Added Calculator

# Creators:

### Yifei29: Main Developer
A 9-Year-Old Lua and Python developer.
### Chambers30101: Backup Developer
A 10-Year-Old Roblox Builder and Devloper
### FireAddict: Admin

